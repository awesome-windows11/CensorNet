 {
  var proxyHosts = {}, checkUrls = [], proxyHostsCl = [], lastLoadHosts = {}, blHosts = [], dataRep = [];
  var timewait = 1E3 * 60 * 15, timewait2 = 19E3, timewait3 = -1, timewaitClSerial = 1E3 * 60 * 60 * 24, timewaitUpdateHost = 1E3 * 60 * 60 * 5, timewait407 = 1E3 * 30 * 1, rep = {};
  var num_tabs;
  var first_api = "";
  var upd407 = 0;
  var isShowMess = {};
  var preazapret = null;
  var presites = null;
  var preurls = null;
  var preproxy = null;
  var ison = true;
  var first = true;
  var attempts = 6;
  var startUrlIndex = 0;
  var endUrlIndex = 1;
  var extArr = ["org", "biz"];
  var prDef = "";
  var prDefCo = "";
  var prDef2 = [["HTTPS uk11.friproxy.biz:443", "uk"], ["HTTPS fr11.friproxy.biz:443", "fr"]];
  var pr2Def2 = ["SOCKS5 uk11.friproxy.biz:1080", "SOCKS5 fr11.friproxy.biz:1080"];
  var prauth = ls.set("prauth");
  var prauth2 = ls.set("prauth2");
  var prauth3 = ls.set("prauth3");
  var prauth4 = ls.set("prauth4");
  var pr = "", prco = "", prip, openPr = false, openPrNoNeed, limitText = "wait";
  var pr2 = "";
  var isProxyHosts = false;
  var isRep = false;
  var news = ls.get("news");
  var updateText = ls.get("updateText");
  var nameTestFile = "/frigate.";
  var noalert = false;
  var noadv = ls.get("noadv");
  var rgetEtag = ls.get("rgetEtag");
  var timerUpdateHost = false;
  var md5api = "";
  var uid = ls.get("uidkey");
  var clearcacheis = true;
  var serial = 0;
  var serialRep = "0";
  var startTime = Date.now();
  var timeClSerial = startTime + timewaitClSerial;
  var detailsApp = chrome.app.getDetails();
  var idContMen = [];
  var iscl = true;
  var proxyOffset = 0;
  var tabUpdateAllArr = {};
  var timerCheckProxy;
  var a = ls.get("a");
  var slink = ls.get("slink");
  var compres = ls.get("compres");
  var autoChangeProxyCount = 0;
  var autoChangeProxyCountMax = 7;
  var GlobalContentLength = 0;
  var GlobalOriginalContentLength = 0;
  var LenCount = 0;
  var ContentLengthCounterStart = ls.get("ContentLengthCounterStart");
  if (!ContentLengthCounterStart) {
    setContentLengthCounterStart();
  }
  var noAutoChangeProxy = ls.get("noAutoChangeProxy");
  var timeOutAuth = 0;
  var proxyUpdate = 1;
  var azapret = [];
  var azaprethide = {};
  var ip = "";
  var sov = 0;
  var azapret3 = {"list":{}, "enable":true, "ext":0, "run":false};
  var slowConnect = ls.get("slow");
  if (slowConnect) {
    setSlow();
  }
  var iid;
  var token;
  var trec = ls.get("trec", uid);
  var tRecAllHosts = {};
}
chrome.runtime.setUninstallURL("https://fri-gate.org/uninstall");
if (!slink) {
  chrome.tabs.create({"url":"/eula.html", "active":true});
  ison = false;
  ls.set("on", false);
}
d2("friGate starting...");
{
  if (!uid) {
    localStorage.clear();
    uid = generatePW();
    ls.set("uidkey", uid, false);
    if (slink) {
      ison = true;
      ls.set("on", true);
    }
  } else {
    if (typeof localStorage["version"] != "undefined") {
      localStorage.clear();
      if (slink) {
        ison = true;
        ls.set("on", true);
      }
    } else {
      first = false;
      if (slink) {
        ison = ls.get("on");
      }
    }
  }
}
var lang = chrome.i18n.getMessage("@@ui_locale");
if (lang != "ru") {
  lang = "en";
}
chrome.browserAction.setBadgeBackgroundColor({"color":[55, 169, 224, 90]});
chrome.webRequest.onBeforeRequest.addListener(reqListenerAll, {urls:["<all_urls>"], types:["main_frame"]}, ["blocking"]);
chrome.idle.onStateChanged.addListener(function(newState) {
  if (newState == "active") {
    getSitesUrl(false, function() {
    });
  }
});
if (updateText) {
  updateText = l("messUpdate");
}
genapi();
getTld();
noalertRead();
proxyRead();
loadhosts();
tRecPrepead(trec);
var GetBlList = function(apiurl, callbackl) {
  if (azapret3.run) {
    return;
  }
  azapret3.run = true;
  var date = new Date;
  azapret3.enable = ls.get("azapret3_enabled");
  if (azapret3.enable === null) {
    azapret3.enable = true;
    ls.set("azapret3_enabled", true);
  }
  if (azapret3.enable) {
    ldb.get("azapret3", function(value) {
      azapret3.list = JSON.parse(value);
    });
    if (azapret3.ext < date.getTime()) {
      var firstRandomElement = apiurl + "/json";
      ReqJson(firstRandomElement, 1E3 * 30, function(resp) {
        azapret3.list = JSON.parse(resp);
        d("azapret3: ", azapret3.list);
        ldb.set("azapret3", JSON.stringify(azapret3.list), function() {
        });
        azapret3.ext = date.getTime() + 60 * 60 * 1000 * 10;
        azapret3.run = false;
        callbackl();
      }, function(resp) {
        azapret3.run = false;
      }, function(resp) {
        azapret3.run = false;
      });
    } else {
      azapret3.run = false;
      callbackl();
    }
  }
};
function setSlow() {
  if (slowConnect) {
    globalTimeout = 70E3;
  } else {
    globalTimeout = 10E3;
  }
}
function onProxyError() {
  chrome.proxy.settings.get({incognito:false}, function(details) {
    var err = false;
    if (details && typeof details.levelOfControl != "undefined" && details.levelOfControl != "controllable_by_this_extension" && details.levelOfControl != "controlled_by_this_extension") {
      err = true;
    }
    if (err && ison) {
      ison = false;
      proxyoff(true, true);
      errIcon();
      chrome.browserAction.setTitle({title:l("messErrOverExtProxy")});
    } else {
      if (!err && !ison) {
        ison = true;
        proxyon();
      }
    }
  });
}
function setUserHostUrl(host, url, list, lid, on) {
  if (on) {
    if (!(url < 0)) {
      checkUrls.include(host + url);
    }
    proxyHosts[host] = {on:false, d:0, bl:false, url:url};
    if (list) {
      proxyHosts[host].l = list;
    }
    proxyHosts[host].lid = lid;
    if (url == -2) {
      proxyHosts[host].ons = true;
    }
    proxyHostsCl.include("*://" + host + "/*");
  } else {
    checkUrls.erase(host + url);
    delete proxyHosts[host];
    proxyHostsCl.erase("*://" + host + "/*");
  }
}
function chNoNeedopenPr() {
  for (var host in proxyHosts) {
    if (proxyHosts.hasOwnProperty(host)) {
      if (typeof proxyHosts[host].l !== "undefined") {
        return false;
      }
    }
  }
  return true;
}
function getMessage(request, sender, sendResponse) {
  if (request) {
    if (request.type == "getTabId") {
      sendResponse({tabId:sender.tab.id});
    } else {
      if (request.type == "sovetnik") {
        sendResponse(noadv);
        return true;
      } else {
        if (request.type == "from_s2" && request.tabHost) {
          if (typeof proxyHosts[request.tabHost] != "undefined") {
            proxyHosts[request.tabHost].hide = request.value;
            saveHostsToLs();
          } else {
            azaprethide[request.tabHost] = request.value;
            ls.set("azaprethide", azaprethide);
          }
        } else {
          if (request.type == "frigate" && request.value) {
            if (request.value == "gettld") {
              getTld();
              d("getTld===", tld);
              preproxy = "";
              setProxy($empty);
            } else {
              if (request.value == "isslowconn") {
                slowConnect = request.val2 ? 1 : 0;
                setSlow();
              }
            }
            if (request.value == "noautochproxy") {
              noAutoChangeProxy = request.val2 ? 1 : 0;
            } else {
              if (request.value == "compres") {
                compres = request.val2 ? 1 : 0;
              } else {
                if (request.value == "anon") {
                  a = request.val2 ? 1 : 0;
                } else {
                  if (request.value == "noalert") {
                    noalertRead();
                  } else {
                    if (request.value == "noadv") {
                      noadvRead();
                    } else {
                      if (request.value == "proxy") {
                        preproxy = "";
                        if (proxyRead() == "f") {
                          openPrNoNeed = chNoNeedopenPr();
                          if (openPr || openPrNoNeed) {
                            setProxy(function() {
                              checkAllTabWhenEnable(false);
                            });
                          } else {
                            getSitesUrl(false, function() {
                              checkAllTabWhenEnable(false);
                            });
                          }
                        } else {
                          setProxy($empty);
                        }
                      } else {
                        if (request.value == "getfrlist") {
                          sendResponse({"proxyHosts":proxyHosts, "az":{"en":azapret3.enable, "count":Object.keys(azapret3.list).length}});
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if (request.type == "chproxy" && request.tabHost && request.url && request.tabId) {
              proxyOffset++;
              proxyUpdate = 1;
              md5api = "";
              openPr = false;
              getSitesUrl(false, function() {
                tabUpdate(false, request.url, request.tabId);
              });
            } else {
              if (request.type == "frigatetabon" && request.tabHost && request.url && request.tabId) {
                proxyHosts[request.tabHost]["man"] = true;
                setProxy(function() {
                  actIcon();
                  tabUpdate(false, request.url, request.tabId);
                });
              } else {
                if (request.type == "frigatetaboff" && request.tabHost && request.url && request.tabId) {
                  proxyHosts[request.tabHost]["man"] = false;
                  setProxy(function() {
                    noActIcon();
                    tabUpdate(false, request.url, request.tabId);
                  });
                } else {
                  if (request.type == "frigateisshow" && request.tabId) {
                    isShowMess[request.tabId] = true;
                  } else {
                    if (request.type == "frigatelistaz") {
                      azapret3.enable = request.value.act == "onlist";
                      ls.set("azapret3_enabled", azapret3.enable);
                      if (ison) {
                        setOrUpdateHandlers();
                      }
                      if (!openPr) {
                        openPr = 0;
                        getSitesUrl(false, function() {
                          checkAllTabWhenEnable(false);
                        });
                        sendResponse(true);
                      } else {
                        setProxy(function() {
                          sendResponse(true);
                        });
                      }
                    } else {
                      if (request.type == "frigatelist") {
                        var on = request.value.act == "onlist";
                        if (on || request.value.act == "offlist") {
                          if (request.value.id) {
                            var lsList = ls.get("list");
                            if (lsList && lsList.length > 0) {
                              if (typeof lsList[request.value.id] !== "undefined") {
                                var siteList = lsList[request.value.id];
                                if (siteList.d.length > 0) {
                                  Object.each(siteList.d, function(val, key) {
                                    if (val.on) {
                                      setUserHostUrl(val.h, val.u, siteList.n, key, on);
                                    }
                                  });
                                  if (ison) {
                                    setOrUpdateHandlers();
                                  }
                                  saveHostsToLs();
                                  if (!openPr) {
                                    openPr = 0;
                                    getSitesUrl(false, function() {
                                      checkAllTabWhenEnable(false);
                                    });
                                  } else {
                                    setProxy(function() {
                                      sendResponse(true);
                                    });
                                  }
                                } else {
                                  sendResponse(true);
                                }
                              }
                            }
                          }
                          return true;
                        } else {
                          if (request.value.act == "delurl") {
                            if (request.value.url == -5) {
                              if (typeof proxyHosts[request.value.host] != "undefined") {
                                if (proxyHosts[request.value.host].ons) {
                                  proxyHosts[request.value.host].ons = -3;
                                } else {
                                  proxyHosts[request.value.host].ons = -1;
                                }
                                saveHostsToLs();
                                setProxy(function() {
                                  checkAllTabWhenEnable(false);
                                  sendResponse(true);
                                });
                                return true;
                              } else {
                                sendResponse(false);
                              }
                              return true;
                            }
                            if (request.value.host && request.value.url) {
                              setUserHostUrl(request.value.host, request.value.url, false, false, false);
                              if (typeof request.value.notApply == "undefined") {
                                saveHostsToLs();
                                if (ison) {
                                  setOrUpdateHandlers();
                                }
                                if (!openPr) {
                                  openPrNoNeed = chNoNeedopenPr();
                                  if (openPrNoNeed) {
                                    onOffLimit();
                                  }
                                }
                                checkAllTabWhenEnable(false);
                                sendResponse(true);
                              } else {
                                sendResponse(true);
                              }
                            } else {
                              sendResponse(true);
                            }
                            return true;
                          } else {
                            if (request.value.act == "churl") {
                              var checkHost = checkHostInProxyHosts("http://" + getClHost(request.value.host));
                              if (checkHost.tabHost) {
                                if (typeof proxyHosts[checkHost.tabHost].lid == "undefined") {
                                  sendResponse("friGate");
                                } else {
                                  sendResponse(proxyHosts[checkHost.tabHost].lid);
                                }
                              } else {
                                sendResponse(false);
                              }
                            } else {
                              if (request.value.act == "url") {
                                if (request.value.url == -5) {
                                  if (typeof proxyHosts[request.value.host] != "undefined") {
                                    if (proxyHosts[request.value.host].ons == -3) {
                                      proxyHosts[request.value.host].ons = true;
                                    } else {
                                      proxyHosts[request.value.host].ons = false;
                                    }
                                    saveHostsToLs();
                                    setProxy(function() {
                                      checkAllTabWhenEnable(false);
                                      sendResponse(true);
                                    });
                                  } else {
                                    sendResponse(false);
                                  }
                                  return true;
                                }
                                setUserHostUrl(request.value.host, request.value.url, request.value.list, request.value.lid, true);
                                if (ison) {
                                  setOrUpdateHandlers();
                                }
                                saveHostsToLs();
                                if (!openPr) {
                                  getSitesUrl(false, function() {
                                    checkAllTabWhenEnable(request.value.host);
                                  });
                                  sendResponse(true);
                                } else {
                                  setProxy(function() {
                                    checkAllTabWhenEnable(request.value.host);
                                    sendResponse(true);
                                  });
                                }
                                return true;
                              }
                            }
                          }
                        }
                        return true;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
function noalertRead() {
  var lsnoalert = ls.get("noalert");
  if (lsnoalert !== null) {
    noalert = lsnoalert;
  }
}
function noadvRead() {
  var lsnoadv = ls.get("noadv");
  if (lsnoadv !== null) {
    noadv = lsnoadv;
  }
  sovetnik.setRemovedState(noadv);
}
function proxyRead() {
  var lspr = ls.get("pr2");
  if (lspr == null || lspr.length < 1) {
    if (prDef) {
      pr = prDef;
      prco = prDefCo;
    } else {
      var prRand = Math.floor(Math.random() * prDef2.length);
      pr = prDef2[prRand][0];
      prco = prDef2[prRand][1];
      pr2 = pr2Def2[prRand];
    }
    prip = getprip(pr);
    return "f";
  } else {
    pr = "";
    pr2 = "";
    lsprL = lspr.length;
    if (lsprL > 0) {
      for (var j = 0; j < lsprL; j++) {
        pr = pr + lspr[j];
        if (j == lsprL - 1) {
          pr = pr + ";";
        }
      }
    }
    prip = "";
    prco = "";
    openPr = true;
    return "o";
  }
}
function checkHostInAntizapret(url) {
  if (!azapret3.enable) {
    return false;
  }
  var azaprethostslen = 0;
  if (!emptyObject(azapret3.list)) {
    azaprethostslen = Object.keys(azapret3.list).length;
  }
  if (azaprethostslen == 0) {
    return false;
  }
  var urlSplit = url.split(/\/+/g);
  if (urlSplit[0] != "http:" && urlSplit[0] != "https:") {
    return false;
  }
  d("checkHostInAntizapret=", urlSplit[1]);
  var host = urlSplit[1];
  if (host in azapret3.list) {
    return host;
  } else {
    var hostSplitDot = host.split(".");
    var hostSplitDotLength = hostSplitDot.length;
    if (hostSplitDotLength > 2) {
      var subdomain = hostSplitDot[hostSplitDotLength - 1];
      for (var i = hostSplitDotLength - 2; i > 0; i--) {
        subdomain = hostSplitDot[i] + "." + subdomain;
        if (subdomain in azapret3.list) {
          return host;
        }
      }
    }
  }
  return false;
}
function checkHostInTld(url) {
  var ret = {};
  var urlSplit = url.split(/\/+/g);
  ret["sheme"] = urlSplit[0] + "//";
  ret["host"] = urlSplit[1];
  if (ret.sheme != "http://" && ret.sheme != "https://") {
    return false;
  }
  var hostSplitDot = ret.host.split(/\./g);
  var hostSplitDotLength = hostSplitDot.length;
  var thisTld = hostSplitDot[hostSplitDotLength - 1];
  if (tld.hasOwnProperty(thisTld) && tld[thisTld]) {
    return thisTld;
  }
  return false;
}
function checkHostInRepTextHosts(url) {
  var ret = [];
  if (dataRep != null) {
    var idata = dataRep.length;
    if (idata > 0) {
      while (idata--) {
        if (typeof dataRep[idata] == "undefined") {
          continue;
        }
        if (dataRep[idata].s.test(url)) {
          ret.push({f:dataRep[idata].f, t:dataRep[idata].t});
        }
      }
    }
  }
  return ret;
}
function checkHostInTopRec(url) {
  var ret = false;
  var urlSplit = url.split(/\/+/g);
  var host = urlSplit[1];
  if (typeof tRecAllHosts[host] !== "undefined") {
    ret = tRecAllHosts[host];
  } else {
    var hostSplitDot = host.split(/\./g);
    var hostSplitDotLength = hostSplitDot.length;
    if (hostSplitDotLength > 1) {
      var tabClHost = hostSplitDot[hostSplitDotLength - 1];
      for (var i = hostSplitDotLength - 2; i > -1; i--) {
        var tabClHost = hostSplitDot[i] + "." + tabClHost;
        if (typeof tRecAllHosts["*." + tabClHost] !== "undefined") {
          ret = tRecAllHosts["*." + tabClHost];
        }
      }
    }
  }
  if (ret !== false) {
    if (trec[ret].hasOwnProperty("reg") && trec[ret].reg) {
      if (!trec[ret].reg.test(url)) {
        ret = false;
      }
    }
  }
  return ret;
}
function checkHostInProxyHosts(url) {
  var ret = {"tabHost":false, "tabClHost":"", "isSheme":false, "allow":false};
  var urlSplit = url.split(/\/+/g);
  var isrethost = false;
  ret["sheme"] = urlSplit[0] + "//";
  ret["host"] = urlSplit[1];
  if (ret.sheme == "http://" || ret.sheme == "https://") {
    ret.isSheme = true;
  }
  if (typeof proxyHosts[ret.host] !== "undefined") {
    isrethost = true;
    ret.tabHost = ret.host;
    ret.tabClHost = ret.host;
  } else {
    var hostSplitDot = ret.host.split(/\./g);
    var hostSplitDotLength = hostSplitDot.length;
    if (hostSplitDotLength > 1) {
      ret.tabClHost = hostSplitDot[hostSplitDotLength - 1];
      for (var i = hostSplitDotLength - 2; i > -1; i--) {
        ret.tabClHost = hostSplitDot[i] + "." + ret.tabClHost;
        if (typeof proxyHosts["*." + ret.tabClHost] !== "undefined") {
          ret.tabHost = "*." + ret.tabClHost;
          break;
        }
      }
    }
  }
  if (ret.tabHost) {
    if (openPr || !openPr && !(isrethost && proxyHosts[ret.host].ons < 0) && typeof proxyHosts[ret.tabHost].lid == "undefined") {
      ret.allow = true;
    }
  }
  return ret;
}
function checkAllTabWhenEnable(host) {
  if (ison) {
    chrome.tabs.query({}, function(tabs) {
      var objHost;
      var tabslength = tabs.length;
      for (var i = 0; i < tabslength; i++) {
        objHost = checkHostInProxyHosts(tabs[i].url);
        if (objHost.tabHost && (!host || host && objHost.tabHost == host) || checkHostInAntizapret(tabs[i].url)) {
          try {
            chrome.tabs.update(tabs[i].id, {url:tabs[i].url}, function() {
            });
          } catch (e) {
          }
        }
      }
    });
  }
}
function tabListener31(tabId, changeInfo, tab) {
  var url;
  if (typeof changeInfo.url !== "undefined") {
    url = changeInfo.url;
  } else {
    url = tab.url;
  }
  tabListenerAll(url, tabId, true, changeInfo.status);
  if (url) {
    var HostInRepTextHosts = checkHostInRepTextHosts(url);
    if (HostInRepTextHosts.length > 0) {
      chrome.tabs.sendMessage(tabId, {"type":"s2r", "rep":HostInRepTextHosts});
    }
  }
}
function tabListener32(info) {
  chrome.tabs.get(info.tabId, function(tab) {
    if (typeof tab.url !== "undefined") {
      tabListenerAll(tab.url, info.tabId, false, false);
    }
  });
}
function tabListenerAll(url, tabId, onlyIco, status) {
  var tmpcheckHost;
  var showRec = false;
  if (url && (status === "complete" || status === false)) {
    showRec = checkHostInTopRec(url);
    if (showRec !== false) {
      chrome.tabs.query({url:url}, function(tabs) {
        if (tabs) {
          var tabsId = tabs.map(function(item, index) {
            return item.id;
          });
        }
        if (tabsId && tabsId.contains(tabId)) {
          chrome.tabs.sendMessage(tabId, trec[showRec]);
        }
      });
    }
  }
  if (ison) {
    if (isProxyHosts && url) {
      var list, hide = false;
      var antozapretlist = false;
      var tldlist = false;
      var tabHost = "";
      tmpcheckHost = checkHostInProxyHosts(url);
      if (tmpcheckHost.tabHost && tmpcheckHost.allow) {
        tabHost = tmpcheckHost.tabHost;
        tmpcheckHost = null;
      } else {
        antozapretlist = checkHostInAntizapret(url);
        if (!antozapretlist) {
          tldlist = checkHostInTld(url);
        }
      }
      if (antozapretlist || tabHost || tldlist) {
        if (onlyIco) {
          if (typeof isShowMess[tabId] == "undefined") {
            if (tldlist) {
              list = "<br><b>." + tldlist + "</b>";
            } else {
              if (antozapretlist) {
                list = "<br><b>ruBlacklist</b>";
              } else {
                if (typeof proxyHosts[tabHost].l == "undefined") {
                  list = "<br><b>friGate</b>";
                } else {
                  list = "<br><b>" + proxyHosts[tabHost].l + "</b>";
                }
              }
            }
            if (tabHost && typeof proxyHosts[tabHost].hide != "undefined") {
              hide = proxyHosts[tabHost].hide;
            } else {
              if (antozapretlist) {
                if (typeof azaprethide[antozapretlist] != "undefined") {
                  hide = azaprethide[antozapretlist];
                }
              }
            }
            if (tldlist) {
              showMess(tabId, [l("messProxyOn"), "", l("messFromList") + list], hide, tldlist, url, 3);
            } else {
              if (antozapretlist) {
                showMess(tabId, [l("messProxyOn"), "", l("messFromList") + list], hide, antozapretlist, url, 3);
              } else {
                if (proxyHosts[tabHost].man) {
                  showMess(tabId, [l("messProxyOnManually"), l("messProxyIsOff"), l("messFromList") + list], hide, tabHost, url, 1);
                } else {
                  if (proxyHosts[tabHost].ons < 0) {
                    showMess(tabId, [l("mess_manually_dis"), "", l("messFromList") + list], hide, tabHost, url, 0);
                  } else {
                    if (proxyHosts[tabHost].ons == true) {
                      showMess(tabId, [l("messTypeCh3"), "", l("messFromList") + list], hide, tabHost, url, 4);
                    } else {
                      if (proxyHosts[tabHost].on) {
                        showMess(tabId, [l("messProxyOn"), "", l("messFromList") + list], hide, tabHost, url, 3);
                      } else {
                        showMess(tabId, [l("messSiteWithoutProxy"), l("messProxyOff"), l("messFromList") + list], hide, tabHost, url, 0);
                      }
                    }
                  }
                }
              }
            }
          }
        }
        chrome.tabs.getSelected(null, function(tab) {
          if (tab.id == tabId) {
            if ((typeof proxyHosts[tabHost] == "undefined" || !(proxyHosts[tabHost].ons < 0)) && (tldlist || antozapretlist || proxyHosts[tabHost].on || proxyHosts[tabHost].ons) || proxyHosts[tabHost].man) {
              actIcon(tabId);
              return true;
            } else {
              listIcon();
              return false;
            }
          }
        });
      }
    }
    noActIcon();
  } else {
    disIcon();
  }
}
function reqListenerAll(details) {
  if (details.tabId && details.url) {
    tabUpdateAllArr[details.tabId] = details.url;
  }
}
var checkResponseHeaders = function(responseHeaders) {
  var locationKey = 0;
  Array.each(responseHeaders, function(val, key) {
    val.name = val.name.toLowerCase();
    if (val.name == "location") {
      locationKey = key;
    }
  });
  return locationKey;
};
var reqOnHeadersReceived = function(details) {
  if (typeof details.responseHeaders == "object") {
    var responseHeadersLen = details.responseHeaders.length;
    var countCheck = 0;
    var serverErr;
    if (responseHeadersLen > 0) {
      for (var i = 0; i < responseHeadersLen; i++) {
        if (typeof details.responseHeaders[i].name != "undefined") {
          if (details.responseHeaders[i].name == "status") {
            serverErr = details.responseHeaders[i].value * 1;
            if (serverErr > 499 && serverErr < 505) {
              countCheck++;
            }
          }
          if (details.responseHeaders[i].name == "server" && details.responseHeaders[i].value == "fri-gate") {
            countCheck++;
          }
        }
      }
      if (countCheck == 2) {
        if (!noAutoChangeProxy) {
          changeProxy(details);
        }
      }
    }
  }
  var reg300 = /(3)\d\d/g;
  if (reg300.test(details.statusLine)) {
    if (details.type == "xmlhttprequest") {
      if (details.url.indexOf("frigate_test_file=") != -1) {
        return {cancel:true};
      } else {
        if (details.url.indexOf("frigate_404_check") != -1) {
          return {cancel:true};
        }
      }
    } else {
      hostObj = checkHostInProxyHosts(details.url);
      if (hostObj.tabHost && !proxyHosts[hostObj.tabHost].on && hostObj.allow) {
        var locationKey = checkResponseHeaders(details.responseHeaders);
        if (locationKey) {
          toUrl = details.responseHeaders[locationKey].value;
          var toUrlAr = toUrl.split(/\/+/g);
          toUrl = toUrlAr[1];
          blHostslength = blHosts.length;
          if (blHostslength > 0) {
            for (var i = 0; i < blHostslength; i++) {
              if (toUrl.indexOf(blHosts[i]) != -1) {
                proxyHosts[hostObj.tabHost].bl = true;
                proxyHosts[hostObj.tabHost].upd = {};
                proxyHosts[hostObj.tabHost].upd[details.tabId] = details.url;
                noSiteRes(hostObj.tabHost, null, details.tabId, details.url, null, null);
              }
            }
          }
        }
      }
    }
  }
  return {cancel:false};
};
function reqListener(details) {
  if (typeof isShowMess[details.tabId] != "undefined") {
    delete isShowMess[details.tabId];
  }
  if ((isProxyHosts || isRep) && details.url) {
    var url = details.url;
    var tmpcheckHost = checkHostInProxyHosts(url);
    if (tmpcheckHost.isSheme) {
      if (isRep) {
        if (typeof rep[tmpcheckHost.host] != "undefined") {
          var newUrl = url.replace(tmpcheckHost.host, rep[tmpcheckHost.host]);
          return {redirectUrl:newUrl};
        }
      }
      if (tmpcheckHost.tabHost && tmpcheckHost.allow && proxyHosts[tmpcheckHost.tabHost].ons != true) {
        var tabHost = tmpcheckHost.tabHost;
        var tabClHost = tmpcheckHost.tabClHost;
        if (!proxyHosts[tabHost].bl) {
          var churl, churl2;
          if (proxyHosts[tabHost].d < Date.now()) {
            proxyHosts[tabHost].bl = true;
            proxyHosts[tabHost].upd = {};
            proxyHosts[tabHost].upd[details.tabId] = url;
            if (typeof proxyHosts[tabHost].url !== "undefined") {
              if (proxyHosts[tabHost].url.indexOf("|") != -1) {
                var urlSplit = proxyHosts[tabHost].url.split(/\|/g);
                var testFile = "robots.txt";
                if (urlSplit.length > 0) {
                  if (urlSplit[1]) {
                    testFile = urlSplit[1];
                  }
                  var errSiteResfu = function() {
                    noSiteRes(tabHost, tabClHost, details.tabId, url, false, 3);
                  };
                  var noSiteResfu = function(ret) {
                    if (ret.indexOf(urlSplit[0]) == -1) {
                      j = false;
                    } else {
                      j = true;
                    }
                    ret = null;
                    noSiteRes(tabHost, tabClHost, details.tabId, url, j, 3);
                  };
                  churl = tmpcheckHost.sheme + tabClHost + "/" + testFile;
                  Req(churl, 10E3, noSiteResfu, errSiteResfu, errSiteResfu, "GET", "frigate_test_file=" + generatePW(5) + Date.now());
                }
              } else {
                if (proxyHosts[tabHost].url == -1) {
                  var noSiteResfu = function(ret) {
                    var reg404 = /(4|5)\d\d/g;
                    if (reg404.test(ret.status)) {
                      j = true;
                    } else {
                      j = false;
                    }
                    ret = null;
                    noSiteRes(tabHost, tabClHost, details.tabId, url, j, 3);
                  };
                  churl = genRandFile(tmpcheckHost.sheme, tabClHost);
                  getUrl3(churl, "get", {}, "", noSiteResfu, noSiteResfu);
                } else {
                  proxyHosts[tabHost].testsize = -2;
                  var noSiteResfu = function(ret) {
                    var j = {};
                    if (ret) {
                      if (typeof ret == "object") {
                        ret = "";
                      }
                      j = h(ret);
                    } else {
                      j = false;
                    }
                    noSiteRes(tabHost, tabClHost, details.tabId, url, j, 2);
                  };
                  churl = tmpcheckHost.sheme + tabClHost + proxyHosts[tabHost].url;
                  getUrl3(churl, "get", {}, "", noSiteResfu, noSiteResfu);
                  churl2 = genRandFile(tmpcheckHost.sheme, tabClHost);
                  getUrl3(churl2, "get", {}, "", noSiteResfu, noSiteResfu);
                }
              }
            } else {
              var noSiteResfu = function(j) {
                noSiteRes(tabHost, tabClHost, details.tabId, url, j, false);
              };
              churl = tmpcheckHost.sheme + tabClHost + nameTestFile + tabClHost + ".js";
              getUrl(churl, "get", "", noSiteResfu, noSiteResfu);
            }
          } else {
            if (!noalert) {
              chrome.tabs.sendMessage(details.tabId, {"type":"showwait"});
            }
            return {cancel:false};
          }
        } else {
          proxyHosts[tabHost].upd[details.tabId] = url;
        }
      } else {
        return {cancel:false};
      }
    }
  }
  return {cancel:false};
}
function onAddAuthHeader(details) {
  if (details.url.substring(0, 5) == "http:") {
    var tabHost = "";
    var azapretlist = false;
    var hostObj = checkHostInProxyHosts(details.url);
    if (hostObj.tabHost && hostObj.allow) {
      tabHost = hostObj.tabHost;
    } else {
      azapretlist = checkHostInAntizapret(details.url);
    }
    if (azapretlist || tabHost && (proxyHosts[hostObj.tabHost].on || proxyHosts[hostObj.tabHost].ons == true || proxyHosts[hostObj.tabHost].man)) {
      if (compres && a) {
        if (prauth4) {
          details.requestHeaders.push({name:"Proxy-Authorization", value:prauth4});
        }
      } else {
        if (compres) {
          if (prauth3) {
            details.requestHeaders.push({name:"Proxy-Authorization", value:prauth3});
          }
        } else {
          if (a) {
            if (prauth2) {
              details.requestHeaders.push({name:"Proxy-Authorization", value:prauth2});
            } else {
              details.requestHeaders.push({name:"Proxy-Authorization", value:"a"});
            }
          } else {
            if (prauth) {
              details.requestHeaders.push({name:"Proxy-Authorization", value:prauth});
            }
          }
        }
      }
    }
  }
  return {requestHeaders:details.requestHeaders};
}
function reqOnResponseStarted(details) {
  if (!noalert) {
    if (isProxyHosts && details.url) {
      var tmpcheckHost = checkHostInProxyHosts(details.url);
      if (tmpcheckHost.tabHost && tmpcheckHost.allow || checkHostInAntizapret(details.url)) {
        chrome.tabs.sendMessage(details.tabId, {"type":"showwait"});
      }
      tmpcheckHost = null;
    }
  }
  if (typeof details.statusCode != "undefined" && details.statusCode == 407) {
    changeProxy(details, true);
    d2(details.statusCode);
  }
}
function reqOnErrorOccurred(details) {
  d("details", details);
  if (details.error.indexOf("ERR_TUNNEL_CONNECTION_FAILED") != -1 || details.error.indexOf("ERR_PROXY_CONNECTION_FAILED") != -1 || details.error.indexOf("ERR_PROXY") != -1) {
    changeProxy(details, true);
  }
  if (typeof details.statusCode != "undefined" && details.statusCode == 404) {
    changeProxy(details);
  }
}
function reqonCompletedForFindErr(details) {
  if (typeof details.responseHeaders == "object") {
    var responseHeadersLen = details.responseHeaders.length;
    if (responseHeadersLen > 0) {
      var needChangeProxy = false;
      for (var i = 0; i < responseHeadersLen; i++) {
        if (typeof details.responseHeaders[i].name != "undefined") {
          if (details.responseHeaders[i].name == "X-Squid-Error" && details.responseHeaders[i].value == "ERR_ACCESS_DENIED 0") {
            needChangeProxy = true;
          }
        }
      }
      if (needChangeProxy) {
        changeProxy(details, true);
      }
    }
  }
}
function changeProxy(details, resetAuth) {
  if (autoChangeProxyCount == 0) {
    proxyOffset = 0;
  }
  if (autoChangeProxyCount <= autoChangeProxyCountMax) {
    autoChangeProxyCount++;
    proxyOffset++;
    proxyUpdate = 1;
    md5api = "";
    openPr = false;
    if (resetAuth) {
      timeOutAuth = 0;
      reGet(function() {
        if (details.url && details.tabId) {
          tabUpdate(null, details.url, details.tabId);
        }
      });
    } else {
      getSitesUrl(false, function() {
        if (details.url && details.tabId) {
          tabUpdate(null, details.url, details.tabId);
        }
      });
    }
  }
}
function onoff() {
  if (ison) {
    proxyoff();
  } else {
    proxyon();
  }
}
function onOffLimit() {
  openPrNoNeed = chNoNeedopenPr();
  if (openPr || openPrNoNeed) {
    limitText = "";
  } else {
    limitText = "lim";
    chrome.browserAction.setTitle({title:l("messErrLim")});
  }
  if (ison) {
    chrome.tabs.getSelected(null, function(tab) {
      tabListenerAll(tab.url, tab.id, true, false);
    });
  }
}
function proxyoff(nosave, errpr) {
  d2("off");
  if (timerUpdateHost) {
    clearInterval(timerUpdateHost);
  }
  timerUpdateHost = false;
  if (!errpr) {
    if (timerCheckProxy) {
      clearInterval(timerCheckProxy);
    }
    timerCheckProxy = false;
  }
  preazapret = null;
  presites = null;
  preurls = null;
  preproxy = null;
  openPr = false;
  md5api = false;
  setOrUpdateHandlers(true);
  setOrUpdateTabHandlers(true);
  disIcon();
  chrome.proxy.settings.clear({scope:"regular"}, function() {
    checkAllTabWhenEnable(false);
    if (!nosave) {
      ison = null;
      ls.set("on", false);
    }
  });
}
function clearcacheNew(t, origins, f) {
  if (clearcacheis) {
    clearcacheis = false;
    try {
      chrome.browsingData.remove({"since":0, "origins":[origins]}, {"appcache":true, "cache":true, "serviceWorkers":true}, f);
    } catch (e) {
      if (typeof f == "function") {
        f();
      }
    }
  }
}
function offHandlersAll() {
  if (chrome.webRequest.onBeforeRequest.hasListener(reqListenerAll)) {
    chrome.webRequest.onBeforeRequest.removeListener(reqListenerAll);
  }
}
function setOrUpdateHandlers(off) {
  offHandlersAll();
  if (chrome.webRequest.onBeforeRequest.hasListener(reqListener)) {
    chrome.webRequest.onBeforeRequest.removeListener(reqListener);
  }
  if (!off) {
    chrome.webRequest.onBeforeRequest.addListener(reqListener, {urls:proxyHostsCl, types:["main_frame"]}, ["blocking"]);
  }
  if (chrome.webRequest.onHeadersReceived.hasListener(reqOnHeadersReceived)) {
    chrome.webRequest.onHeadersReceived.removeListener(reqOnHeadersReceived);
  }
  if (!off) {
    chrome.webRequest.onHeadersReceived.addListener(reqOnHeadersReceived, {urls:proxyHostsCl, types:["xmlhttprequest", "main_frame"]}, ["blocking", "responseHeaders"]);
  }
  if (chrome.webRequest.onErrorOccurred.hasListener(reqOnErrorOccurred)) {
    chrome.webRequest.onErrorOccurred.removeListener(reqOnErrorOccurred);
  }
  if (!off) {
    chrome.webRequest.onErrorOccurred.addListener(reqOnErrorOccurred, {urls:proxyHostsCl, types:["main_frame"]});
  }
  if (chrome.webRequest.onHeadersReceived.hasListener(reqOnResponseStarted)) {
    chrome.webRequest.onHeadersReceived.removeListener(reqOnResponseStarted);
  }
  if (!off) {
    chrome.webRequest.onHeadersReceived.addListener(reqOnResponseStarted, {urls:proxyHostsCl, types:["main_frame"]});
  }
  if (chrome.webRequest.onResponseStarted.hasListener(reqOnResponseStarted)) {
    chrome.webRequest.onResponseStarted.removeListener(reqOnResponseStarted);
  }
  if (!off) {
    chrome.webRequest.onResponseStarted.addListener(reqOnResponseStarted, {urls:proxyHostsCl, types:["main_frame"]});
  }
  if (chrome.webRequest.onCompleted.hasListener(reqOnResponseStarted)) {
    chrome.webRequest.onCompleted.removeListener(reqOnResponseStarted);
  }
  if (!off) {
    chrome.webRequest.onCompleted.addListener(reqOnResponseStarted, {urls:proxyHostsCl, types:["main_frame"]});
  }
  if (chrome.webRequest.onCompleted.hasListener(reqonCompletedForFindErr)) {
    chrome.webRequest.onCompleted.removeListener(reqonCompletedForFindErr);
  }
  if (!off) {
    chrome.webRequest.onCompleted.addListener(reqonCompletedForFindErr, {urls:proxyHostsCl, types:["main_frame"]}, ["responseHeaders"]);
  }
  if (chrome.webRequest.onBeforeSendHeaders.hasListener(onAddAuthHeader)) {
    chrome.webRequest.onBeforeSendHeaders.removeListener(onAddAuthHeader);
  }
  if (!off) {
    chrome.webRequest.onBeforeSendHeaders.addListener(onAddAuthHeader, {urls:["<all_urls>"]}, ["requestHeaders", "blocking"]);
  }
}
function setOrUpdateTabHandlers(off) {
  if (chrome.tabs.onUpdated.hasListener(tabListener31)) {
    chrome.tabs.onUpdated.removeListener(tabListener31);
  }
  if (chrome.tabs.onActivated.hasListener(tabListener32)) {
    chrome.tabs.onActivated.removeListener(tabListener32);
  }
  if (!off) {
    chrome.tabs.onUpdated.addListener(tabListener31);
    chrome.tabs.onActivated.addListener(tabListener32);
  }
}
function proxyon(itIsInit) {
  d2("on");
  chrome.browserAction.setBadgeText({"text":"wait"});
  limitText = "wait";
  chrome.proxy.settings.get({"incognito":false}, function(details) {
    if (details && typeof details.levelOfControl != "undefined" && details.levelOfControl != "controllable_by_this_extension" && details.levelOfControl != "controlled_by_this_extension") {
      ison = false;
      chrome.browserAction.setTitle({title:l("messErrOverExtProxy")});
      errIcon();
      return false;
    }
    if (!timerCheckProxy) {
      timerCheckProxy = setInterval(onProxyError, 3000);
    }
    ison = true;
    if (!itIsInit) {
      if (isProxyHosts || isRep) {
        setProxy(function() {
          setOrUpdateHandlers(0);
          setOrUpdateTabHandlers(0);
        });
      }
      proxyOffset++;
      serial = 0;
    }
    openPrNoNeed = chNoNeedopenPr();
    if (proxyHostsCl.length > 0) {
      proxyUpdate = 2;
      getSitesUrl(false, function() {
        serial = 0;
        proxyUpdate = 0;
        getSitesUrl(false, function() {
          checkAllTabWhenEnable(false);
        });
      });
    } else {
      first_api = "&first_api";
      proxyUpdate = 1;
      getSitesUrl(false, function() {
        checkAllTabWhenEnable(false);
      });
    }
    if (!timerUpdateHost) {
      timerUpdateHost = setInterval(getSitesUrl, timewaitUpdateHost);
    }
    chrome.tabs.getSelected(null, function(tab) {
      tabListenerAll(tab.url, tab.id, true, false);
    });
    ls.set("on", true);
    clearcacheis = true;
  });
}
function actIcon() {
  if (a) {
    chrome.browserAction.setIcon({path:"im/38aan.png"});
    chrome.browserAction.setTitle({title:l("messProxyOnAn")});
  } else {
    chrome.browserAction.setIcon({path:"im/38a.png"});
    chrome.browserAction.setTitle({title:l("messProxyOn")});
  }
  chrome.browserAction.setBadgeText({"text":limitText});
}
function listIcon() {
  chrome.browserAction.setTitle({title:l("browser_action_title")});
  if (a) {
    chrome.browserAction.setIcon({path:"im/38lan.png"});
  } else {
    chrome.browserAction.setIcon({path:"im/38l.png"});
  }
  chrome.browserAction.setBadgeText({"text":limitText});
}
function noActIcon() {
  chrome.browserAction.setTitle({title:l("browser_action_title")});
  if (a) {
    chrome.browserAction.setIcon({path:"im/38an.png"});
  } else {
    chrome.browserAction.setIcon({path:"im/38.png"});
  }
  chrome.browserAction.setBadgeText({"text":limitText});
}
function disIcon() {
  chrome.browserAction.setIcon({path:"im/38g.png"});
  chrome.browserAction.setBadgeText({"text":"off"});
  chrome.browserAction.setTitle({title:l("browser_action_title")});
}
function errIcon() {
  chrome.browserAction.setIcon({path:"im/38g.png"});
  chrome.browserAction.setTitle({title:l("messErrOverExtProxy")});
  chrome.browserAction.setBadgeText({"text":"err"});
}
function showMess(tabId, mess, hide, tabHost, url, isonepage) {
  if (!noalert) {
    chrome.tabs.query({url:url}, function(tabs) {
      if (tabs) {
        var tabsId = tabs.map(function(item, index) {
          return item.id;
        });
      }
      if (tabsId.contains(tabId)) {
        chrome.tabs.sendMessage(tabId, {"type":"s2", "tabHost":tabHost, "tabUrl":url, "hide":hide, "tabId":tabId, u:updateText, n:news, "pr":[prip + " " + l("messChange"), prco], "value":{"dop":mess, "isonepage":isonepage}});
      }
    });
  }
}
function tabUpdateAll() {
  if (!emptyObject(tabUpdateAllArr)) {
    chrome.tabs.query({}, function(tabs) {
      var ntid;
      var tabsId = tabs.map(function(item) {
        return item.id;
      });
      for (var tid in tabUpdateAllArr) {
        if (tabUpdateAllArr.hasOwnProperty(tid)) {
          ntid = parseInt(tid);
          if (tabsId.contains(ntid)) {
            try {
              chrome.tabs.update(ntid, {url:tabUpdateAllArr[tid]}, function() {
              });
            } catch (e) {
            }
          }
        }
      }
      tabUpdateAllArr = {};
    });
  }
}
function tabUpdate(host, url, tabId) {
  d("tabUpdate host", host);
  clearcacheNew(0, url, function() {
    if (host && host.length > 0) {
      proxyHosts[host].bl = false;
      if (typeof proxyHosts[host].upd == "object" && !emptyObject(proxyHosts[host].upd) > 0) {
        chrome.tabs.query({}, function(tabs) {
          var tabsId = tabs.map(function(item, index) {
            return item.id;
          });
          d("proxyHosts[host].upd", proxyHosts[host].upd);
          if (typeof proxyHosts[host].upd == "object") {
            Object.each(proxyHosts[host].upd, function(url2, tabId2) {
              tabId2 = parseInt(tabId2);
              d("tabId2", tabId2);
              d("url2", url2);
              if (tabsId.contains(tabId2)) {
                try {
                  chrome.tabs.update(tabId2, {url:url2}, function() {
                  });
                } catch (e) {
                }
              }
            });
          }
          delete proxyHosts[host].upd;
        });
      } else {
        delete proxyHosts[host].upd;
      }
    } else {
      try {
        chrome.tabs.update(tabId, {url:url}, $empty);
      } catch (e) {
      }
    }
    clearcacheis = true;
  });
}
function tRecPrepead(data) {
  if (typeof data !== "object" || data === null) {
    return;
  }
  for (var i = 0, len = data.length; i < len; i++) {
    if (!data[i].hasOwnProperty("hosts")) {
      continue;
    }
    if (data[i].hasOwnProperty("reg") && data[i].reg) {
      trec[i].reg = new RegExp(data[i].reg, "igm");
    }
    var hostsArr = data[i]["hosts"].split(",");
    while (val = hostsArr.shift()) {
      tRecAllHosts[val] = i;
    }
  }
}
function noSiteRes(host, resHost, tabId, url, j, type) {
  var noSetProxy = false;
  if ((type == 2 || type == 7) && typeof j.s !== "undefined") {
    if (proxyHosts[host].testsize == -2) {
      proxyHosts[host].testsize = j["s"];
      proxyHosts[host].testhash = j["h"];
      return true;
    } else {
      if (type == 7) {
        if (checkN(proxyHosts[host].testsize, j["s"], 15)) {
          if (compareH(proxyHosts[host], j["h"]) < 0.15) {
            noSetProxy = true;
          }
        }
      } else {
        if (type == 2) {
          noSetProxy = true;
          if (checkN(proxyHosts[host].testsize, j["s"], 15)) {
            if (compareH(proxyHosts[host], j["h"]) < 0.15) {
              noSetProxy = false;
            }
          }
        }
      }
      delete proxyHosts[host].testsize;
      delete proxyHosts[host].testhash;
    }
  }
  var preOn = proxyHosts[host].on;
  if (type == 3 && j || type == 2 && noSetProxy || !type && j && typeof j.res !== "undefined" && j["res"] == resHost) {
    d2(host + " - available");
    proxyHosts[host].on = false;
    proxyHosts[host].d = Date.now() + timewait2;
    if (preOn) {
      setProxy(function() {
        noActIcon();
        tabUpdate(host, url, tabId);
      });
    } else {
    }
  } else {
    d2(host + " - not available");
    proxyHosts[host].on = true;
    proxyHosts[host].d = Date.now() + timewait;
    if (!preOn) {
      setProxy(function() {
        actIcon();
        tabUpdate(host, url, tabId);
      });
    } else {
    }
  }
}
var ind = startUrlIndex - 1;
var indExt = 0;
function genNewUrl() {
  var inds = "";
  ind++;
  if (ind > endUrlIndex) {
    ind = startUrlIndex;
    indExt++;
    if (indExt > extArr.length - 1) {
      indExt = 0;
    }
  }
  if (ind != endUrlIndex) {
    inds = ind;
  }
  ext = extArr[indExt];
  return "https://apigo.fri-gate" + inds + "." + ext + apiPath + apiFile;
}
function reGet(resfu) {
  if (apioffset + 2 > apicount) {
    if (pr == "") {
      proxyoff();
    } else {
    }
    apioffset = 0;
    return true;
  } else {
    apioffset = apioffset + 1;
    setTimeout(function() {
      getSitesUrl(false, resfu);
    }, 3E3);
  }
}
function saveHostsToLs() {
  var toLs = {};
  if (!emptyObject(proxyHosts)) {
    var value;
    for (var host in proxyHosts) {
      if (proxyHosts.hasOwnProperty(host)) {
        value = proxyHosts[host];
        if (typeof value["ons"] !== "undefined") {
          toLs[host] = {"ons":value["ons"]};
        } else {
          toLs[host] = {};
        }
        if (typeof value["url"] !== "undefined" && value["url"]) {
          toLs[host].url = value["url"];
        }
        if (typeof value["l"] !== "undefined" && value["l"]) {
          toLs[host].l = value["l"];
        }
        if (typeof value["lid"] !== "undefined" && value["lid"]) {
          toLs[host].lid = value["lid"];
        }
        if (typeof value["hide"] !== "uefined" && value["hide"]) {
          toLs[host].hide = true;
        }
      }
    }
  }
  ls.set("hosts", toLs, uid);
}
function savenewhosts(newhosts, delhost) {
  var add = 0, del = 0;
  if (delhost && !emptyObject(delhost) && !emptyObject(proxyHosts)) {
    Array.each(delhost, function(host, ind) {
      if (typeof proxyHosts[host] != "undefined" && typeof proxyHosts[host]["lid"] == "undefined") {
        delete proxyHosts[host];
        proxyHostsCl.erase("*://" + host + "/*");
        del++;
      }
    });
  }
  if (!proxyHosts) {
    proxyHosts = {};
  }
  var tmpLs = ls.get("list");
  var tmpHostsFromLs = {};
  if (!emptyObject(tmpLs)) {
    Array.each(tmpLs, function(ulist, i) {
      Array.each(ulist.d, function(hostObj) {
        tmpHostsFromLs[hostObj.h] = true;
      });
    });
    tmpLs = {};
  }
  Object.each(newhosts, function(value) {
    var host = value.h;
    if (!host) {
      return;
    }
    if (typeof proxyHosts[host] == "undefined") {
      if (typeof tmpHostsFromLs[host] == "undefined") {
        proxyHosts[host] = {on:false, d:0, bl:false};
        if (typeof value.ons != "undefined" && value.ons) {
          proxyHosts[host]["ons"] = true;
        } else {
          proxyHosts[host]["ons"] = false;
        }
        if (typeof value.url != "undefined" && value.url) {
          proxyHosts[host]["url"] = value.url;
        }
        proxyHostsCl.include("*://" + host + "/*");
        isChange = true;
        isProxyHosts = true;
        add++;
      }
    } else {
      if (typeof proxyHosts[host]["lid"] == "undefined") {
        if (typeof value.url != "undefined" && value.url) {
          if (typeof proxyHosts[host]["url"] == "undefined" || proxyHosts[host]["url"] != value.url) {
            proxyHosts[host]["url"] = value.url;
            isChange = true;
            isProxyHosts = true;
            add++;
          }
        }
      }
    }
  });
  var proxyHosts2 = {};
  var newhostsKeys = Object.keys(newhosts);
  if (newhostsKeys.length > 130) {
    Object.each(proxyHosts, function(value, host) {
      for (var i = 0, len = newhostsKeys.length; i < len; i++) {
        if (host == newhosts[newhostsKeys[i]].h || typeof value["lid"] != "undefined") {
          proxyHosts2[host] = value;
          return;
        }
      }
      del++;
    });
  }
  proxyHosts = proxyHosts2;
  if (add || del) {
    d2("save to friGate host. add:" + add + ", del:" + del);
    saveHostsToLs();
    return true;
  } else {
    return false;
  }
}
function proxyHostsAdd(host, value) {
  var ret = {on:false, d:0, bl:false, ons:false};
  if (typeof value["ons"] !== "undefined") {
    ret["ons"] = value["ons"];
  }
  if (typeof value["l"] !== "undefined" && value["l"]) {
    ret["l"] = value["l"];
  }
  if (typeof value["lid"] !== "undefined" && value["lid"]) {
    ret["lid"] = value["lid"];
  }
  if (typeof value["url"] !== "undefined" && value["url"]) {
    ret["url"] = value.url;
    if (!(value.url < 0)) {
      checkUrls.push(host + value.url);
    }
  }
  if (typeof value["hide"] !== "undefined" && value["hide"]) {
    ret["hide"] = true;
  }
  return ret;
}
function parseRepText(dd) {
  var tmpDataRep = [];
  if (dd != null) {
    var idata = dd.length;
    if (idata > 0) {
      while (idata--) {
        if (typeof dd[idata] == "undefined") {
          continue;
        }
        tmpDataRep.push({f:dd[idata].f, t:dd[idata].t, s:RegExp(dd[idata].s, "i")});
      }
    }
  }
  return tmpDataRep;
}
function loadhosts() {
  azaprethide = ls.get("azaprethide");
  if (!azaprethide) {
    azaprethide = {};
  }
  var proxyHostsLength = 0;
  proxyHosts = {};
  proxyHostsCl = [];
  checkUrls = [];
  var tmpLs = ls.get("hosts", uid);
  if (!emptyObject(tmpLs)) {
    for (var host in tmpLs) {
      if (host && tmpLs.hasOwnProperty(host)) {
        var value = tmpLs[host];
        proxyHosts[host] = proxyHostsAdd(host, value);
        proxyHostsLength++;
        proxyHostsCl.push("*://" + host + "/*");
        isProxyHosts = true;
      }
    }
  }
  var tmpLs = ls.get("list");
  if (!emptyObject(tmpLs)) {
    Array.each(tmpLs, function(ulist, i) {
      if (!ulist.on) {
        return;
      }
      Array.each(ulist.d, function(hostObj) {
        var host = hostObj.h;
        if (!hostObj.on) {
          return;
        }
        if (typeof proxyHosts[host] != "undefined") {
          return;
        }
        var value = {ons:true, l:ulist.n, lid:i, url:hostObj.u};
        proxyHosts[host] = proxyHostsAdd(host, value);
        proxyHostsLength++;
        proxyHostsCl.push("*://" + host + "/*");
        isProxyHosts = true;
      });
    });
  }
  var tmpDataRep = ls.get("dataRep", uid);
  if (typeof tmpDataRep === "object") {
    dataRep = parseRepText(tmpDataRep);
  }
  var tmpSerialRep = ls.get("serialRep", false);
  if (tmpSerialRep) {
    serialRep = tmpSerialRep;
  }
  var tmprep = ls.get("redir", uid);
  if (tmprep && typeof tmprep == "object") {
    for (var host in tmprep) {
      if (tmprep.hasOwnProperty(host)) {
        proxyHostsCl.include("*://" + host + "/*");
      }
    }
    rep = tmprep;
    isRep = true;
  }
  if (proxyHostsCl.length < 1) {
    serial = 0;
  }
  d2("loading from localStorage " + proxyHostsLength + " hosts");
}
function setProxy(endfunction) {
  var sites = "";
  var azaprethosts = "";
  var urls = "[]";
  var i = false;
  var j = 0;
  var pHosts = [];
  var src = "";
  if (ison) {
    for (var host in proxyHosts) {
      if (proxyHosts.hasOwnProperty(host)) {
        var value = proxyHosts[host];
        if (openPr || !openPr && typeof proxyHosts[host].lid == "undefined") {
          if (!(value.ons < 0) && (value.on || value.ons) || value.man) {
            i = true;
            pHosts.push(host);
          }
        }
      }
    }
    azaprethosts = JSON.stringify(azapret3);
    var md5azaprethosts = md5(azaprethosts);
    var azaprethostslen = 0;
    if (!emptyObject(azapret3.list)) {
      azaprethostslen = Object.keys(azapret3.list).length;
    }
    sites = JSON.stringify(pHosts);
    var md5sites = md5(sites);
    j = checkUrls.length;
    if (j > 0) {
      urls = JSON.stringify(checkUrls);
    }
    var md5url = md5(urls);
    if (preazapret != md5azaprethosts || presites != md5sites || preurls != md5url || preproxy != pr) {
      preazapret = md5azaprethosts;
      presites = md5sites;
      preurls = md5url;
      preproxy = pr;
      if (i || j > 0 || azaprethostslen > 0) {
        var httpproxy = pr;
        var httpsproxy = pr2;
        if (!httpsproxy) {
          httpsproxy = "DIRECT";
        }
        var proxy_for_tld = "";
        for (var key in tld) {
          if (tld.hasOwnProperty(key) && tld[key]) {
            proxy_for_tld = proxy_for_tld + "if (dnsDomainIs(host, '." + key + "')) {return '" + httpsproxy + "';} ";
          }
        }
        d("========azapret3.list.length=======", azaprethostslen);
        if (azapret3.enable && azaprethostslen > 0) {
          src = "var sitesAz = " + JSON.stringify(azapret3.list) + "; if (host in sitesAz) {is = true} else { var hostSplitDot = host.split('.'); var hostSplitDotLength = hostSplitDot.length; if (hostSplitDotLength > 2) { var subdomain = hostSplitDot[hostSplitDotLength - 1]; for (var i = hostSplitDotLength - 2; i > 0; i--) { subdomain = hostSplitDot[i] + '.' + subdomain; if (subdomain in sitesAz) { is = true; break;}}}}";
        }
        postclearproxy = function() {
          var scr = "function FindProxyForURL(url, host) {" + "var schema=url.substring(0,5); " + "if ( schema!='https' && schema!='http:' ) return 'DIRECT'; " + "if ( shExpMatch( url,'*/aj/frigate/api/+" + apiFile + "*' ) ) return 'DIRECT'; " + "if ( shExpMatch( url,'https://api3.fri*:80/' ) ) return 'DIRECT'; " + 'if (shExpMatch( url,"*' + nameTestFile + '" + host + ".js*") ) return \'DIRECT\'; ' + "if ( url.indexOf('frigate_test_file=')!=-1 ) return 'DIRECT'; " + "if (shExpMatch( url,'*/frigate_404_check_*.png*') ) return 'DIRECT'; " + 
          "var is = false;" + src + "if (!is) {" + "var urls = " + urls + "; " + "var url2=url.substring(url.indexOf('//')+2);" + "if ( urls.indexOf(url2)!=-1 )" + " return 'DIRECT';" + "var sites = " + sites + "; " + "var i; is = false;" + "while (i = sites.shift()) { " + "if (i == host) { is = true; break;} " + "if ( i[0] == '*') { " + "var lenHost = -1*(i.length-2); " + "if (i.substr(lenHost) == host) { is = true; break; } " + "lenHost = -1*(i.length-1); " + "if (i.substr(lenHost) == host.substr(lenHost)) { is = true; break; } " + 
          "}}} " + "if (is) {" + "if ( schema=='http:' ) " + "return '" + httpproxy + "'; else " + "return '" + httpsproxy + "';" + "} " + proxy_for_tld + "return 'DIRECT';" + "}";
          var config = {mode:"pac_script", pacScript:{data:scr}};
          try {
            chrome.proxy.settings.set({value:config, scope:"regular"}, endfunction);
          } catch (e) {
            endfunction();
          }
        };
      } else {
        postclearproxy = endfunction;
      }
      try {
        chrome.proxy.settings.clear({scope:"regular"}, postclearproxy);
      } catch (e) {
        postclearproxy();
      }
      return true;
    }
  }
  if (typeof endfunction === "function") {
    endfunction();
  }
}
function rget() {
  Req("https://fri-gate.org/data.json", 30E3, function(ret, heads) {
    var j;
    if (!ret) {
      return;
    }
    var regexp = /ETag:\s+\"(.+)\"/ig;
    var result = regexp.exec(heads);
    if (result.length > 0 && result[1]) {
      ls.set("rgetEtag", result[1], false);
    }
    try {
      j = JSON.decode(ret);
    } catch (e) {
    }
    if (!j || typeof j.data !== "object") {
      return;
    }
    ls.set("trec", j.data, uid);
    trec = j.data;
    tRecPrepead(trec);
  }, function(error) {
  }, function(timeout) {
  }, "GET", null, {"If-None-Match":rgetEtag});
}
function getSitesUrl(urlGet, resfu) {
  if (!openPr) {
    chrome.browserAction.setTitle({title:"wait"});
  }
  var now = Date.now();
  if (timeClSerial < now) {
    serial = 0;
    timeClSerial = now + timewaitClSerial;
  }
  urlGet = getapiurl(apioffset);
  GetBlList(urlGet, function() {
    if (ison) {
      setOrUpdateHandlers();
      setOrUpdateTabHandlers();
    }
    setProxy(resfu);
  });
  if (apicount < 1) {
    if (now - apistarttime < 10E3) {
      setTimeout(function() {
        getSitesUrl(urlGet, resfu);
      }, 3E3);
    } else {
      if (apiloadattempts > 3) {
        proxyoff();
        return;
      }
      genapi();
      setTimeout(function() {
        getSitesUrl(urlGet, resfu);
      }, 3E3);
    }
    return;
  }
  d("urlGet", urlGet);
  getUrl3(urlGet + "/?", "post", {}, "new=1" + "&k=" + uid + "&t=" + timeOutAuth + "&s=" + serial + "&ip=" + ip + "&po=" + proxyOffset + "&pu=" + proxyUpdate + first_api, function(error) {
    d("apiErr", error);
    reGet(resfu);
  }, function(enc) {
    if (enc) {
      apiloadattempts = 0;
      if (proxyUpdate != 2) {
        getUrl3(urlGet + "/?" + "r", "post", {}, "k=" + uid + "&s=" + serialRep, function(error) {
          d("apiErr", error);
        }, function(enc2) {
          if (enc2 == "") {
            return;
          }
          if (enc == "-") {
            return;
          }
          try {
            var j = JSON.decode(Utf8.decode(XXTEA.decrypt(Base64.decode(enc2), uid)));
          } catch (e) {
          }
          enc = null;
          if (j == undefined || typeof j != "object") {
            return;
          }
          if (j.hasOwnProperty("d") && typeof j.d == "object") {
            if (j.hasOwnProperty("h") && j.h) {
              serialRep = j.h;
              ls.set("serialRep", serialRep, false);
            }
            ls.set("dataRep", j.d, uid);
            dataRep = parseRepText(j.d);
          }
        });
      }
      if (enc != "noUpdate") {
        d("len", enc.length);
        var tmpMd5api = md5(enc), isnewhosts = false, isnewpr = false, isnewver = false;
        if (tmpMd5api != md5api) {
          try {
            var j = JSON.decode(XXTEA.decrypt(Base64.decode(enc), uid));
          } catch (e) {
          }
          enc = null;
          d("j", j);
          if (Object.keys(j).length == 7) {
            d("j", j);
          }
          if (j != undefined && typeof j == "object") {
            md5api = tmpMd5api;
            first_api = "";
            if (j.serial) {
              serial = j.serial;
            }
            if (j.r && Object.getLength(j.r) > 0) {
              isRep = true;
              var newrep = {};
              Array.each(j.r, function(value, key) {
                newrep[value.f] = value.t;
                proxyHostsCl.include("*://" + value.f + "/*");
              });
              rep = newrep;
              ls.set("redir", rep, uid);
            }
            if (j.ip) {
              ip = j.ip;
              d2("you IP: " + j.ip);
            }
            if (j.prauth) {
              prauth = j.prauth;
              ls.set("prauth", prauth, false);
            }
            if (j.prauth2) {
              prauth2 = j.prauth2;
              ls.set("prauth2", prauth2, false);
            }
            if (j.prauth3) {
              prauth3 = j.prauth3;
              ls.set("prauth3", prauth3, false);
            }
            if (j.prauth4) {
              prauth4 = j.prauth4;
              ls.set("prauth4", prauth4, false);
            }
            if (j.pr) {
              proxyUpdate = 0;
              prDef = j.pr;
              var lspr = ls.get("pr2");
              if (!lspr || lspr.length < 1) {
                if (prDef != pr) {
                  prDefCo = j.prco;
                  pr = prDef;
                  prco = prDefCo;
                  prip = getprip(pr);
                  if (j.pr2) {
                    if (j.pr2 == "pr") {
                      pr2 = j.pr;
                    } else {
                      pr2 = j.pr2;
                    }
                  }
                  isnewpr = true;
                }
              } else {
                d2("use own proxy");
              }
            }
            if (typeof j.po != "undefined") {
              proxyOffset = j.po;
            }
            if (j.blHosts && j.blHosts.length > 0) {
              blHosts = j.blHosts;
            }
            if (j.azapret && typeof j.azapret == "object" && j.azapret.length > 0) {
              azapret = j.azapret;
              d("loading antizapret: " + azapret.length);
              azapret = arrayUnique(azapret);
              d("loading antizapret2: " + azapret.length);
              isnewpr = true;
              d2("loading antizapret: " + azapret.length + " hosts");
            }
            if (j.proxyHosts) {
              lastLoadHosts = j.proxyHosts;
              d2("loading from web: " + j.proxyHosts.length + " hosts");
              isnewhosts = savenewhosts(j.proxyHosts, j.delhost);
            }
            if (j.err == 0 || j.err == "0") {
              openPr = true;
            }
            onOffLimit();
            if (j.news) {
              news = j.news;
              ls.set("news", j.news);
            }
            if (j.t) {
              timeOutAuth = j.t;
            }
            if (j.sov) {
              sov = j.sov;
            }
            if (j.ver) {
              var verAppArr = detailsApp.version.split(/\./g);
              var verArr = j.ver.split(/\./g);
              for (var i = 0, len = verAppArr.length; i < len; i++) {
                if (verAppArr[i].toInt() < verArr[i].toInt()) {
                  isnewver = true;
                  break;
                }
              }
              if (isnewver) {
                updateText = l("messUpdate");
                ls.set("updateText", true);
              } else {
                updateText = "";
                ls.set("updateText", false);
              }
            }
            if (isnewhosts || isnewpr) {
              if (isnewhosts && ison) {
                setOrUpdateHandlers();
                setOrUpdateTabHandlers();
              }
              setProxy(resfu);
            } else {
              if (typeof resfu == "function") {
                resfu();
              }
            }
          } else {
            reGet(resfu);
            d2("error load 1");
          }
        } else {
          onOffLimit();
        }
      } else {
        md5api = "";
        d("noUpd", "");
        onOffLimit();
      }
    } else {
      reGet(resfu);
      d2("error load 2");
    }
  });
}
(function(window, document) {
  var ready, loaded, checks = [], shouldPoll, timer, testElement = document.createElement("div");
  var domready = function() {
    clearTimeout(timer);
    if (!ready) {
      Browser.loaded = ready = true;
      document.removeListener("DOMContentLoaded", domready).removeListener("readystatechange", check);
      document.fireEvent("domready");
      window.fireEvent("domready");
    }
    document = window = testElement = null;
  };
  var check = function() {
    for (var i = checks.length; i--;) {
      if (checks[i]()) {
        domready();
        return true;
      }
    }
    return false;
  };
  var poll = function() {
    clearTimeout(timer);
    if (!check()) {
      timer = setTimeout(poll, 10);
    }
  };
  document.addListener("DOMContentLoaded", domready);
  var doScrollWorks = function() {
    try {
      testElement.doScroll();
      return true;
    } catch (e) {
    }
    return false;
  };
  if (testElement.doScroll && !doScrollWorks()) {
    checks.push(doScrollWorks);
    shouldPoll = true;
  }
  if (document.readyState) {
    checks.push(function() {
      var state = document.readyState;
      return state == "loaded" || state == "complete";
    });
  }
  if ("onreadystatechange" in document) {
    document.addListener("readystatechange", check);
  } else {
    shouldPoll = true;
  }
  if (shouldPoll) {
    poll();
  }
  Element.Events.domready = {onAdd:function(fn) {
    if (ready) {
      fn.call(this);
    }
  }};
  Element.Events.load = {base:"load", onAdd:function(fn) {
    if (loaded && this == window) {
      fn.call(this);
    }
  }, condition:function() {
    if (this == window) {
      domready();
      delete Element.Events.load;
    }
    return true;
  }};
  window.addEvent("load", function() {
    loaded = true;
  });
})(window, document);
chrome.proxy.settings.get({"incognito":false}, function(details) {
  if (details && typeof details.levelOfControl != "undefined" && details.levelOfControl != "controllable_by_this_extension" && details.levelOfControl != "controlled_by_this_extension") {
    ison = false;
    errIcon();
  }
  if (ison && proxyHostsCl.length > 0) {
    if (isProxyHosts || isRep) {
      setOrUpdateHandlers();
    } else {
      offHandlersAll();
    }
    tabUpdateAll();
    setOrUpdateTabHandlers(0);
  } else {
    offHandlersAll();
    tabUpdateAll();
    disIcon();
  }
  window.addEvent("domready", function load(event) {
    chrome[runtimeOrExtension].onMessage.addListener(getMessage);
    chrome.tabs.onRemoved.addListener(function() {
      chrome.tabs.query({}, function(tabs) {
        if (!tabs.length && iscl) {
          var unsleep = function() {
            if (!iscl) {
              iscl = true;
              proxyon();
              if (chrome.tabs.onCreated.hasListener(unsleep)) {
                chrome.tabs.onCreated.removeListener(unsleep);
              }
            }
          };
          iscl = false;
          proxyoff(true);
          if (!chrome.tabs.onCreated.hasListener(unsleep)) {
            chrome.tabs.onCreated.addListener(unsleep);
          }
        }
      });
    });
    if (ison) {
      setTimeout(function() {
        proxyon(true);
      }, 300);
    } else {
      if (first) {
        first_api = "&first_api";
        getSitesUrl();
      }
    }
    chrome.browserAction.onClicked.addListener(function() {
      onoff();
    });
    setTimeout(function() {
      rget();
    }, 5000);
  });
});

